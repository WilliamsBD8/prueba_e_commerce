package com.example.pedidos.domain.model;

public enum OrderStates {
    PENDING,
    CONFIRMED,
    SHIPPED,
    DELIVERED,
    CANCELLED,
    FAILED
}
